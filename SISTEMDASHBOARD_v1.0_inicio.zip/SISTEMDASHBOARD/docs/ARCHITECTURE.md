# Arquitectura SISTEMDASHBOARD

## Estrategia BOTH
WispHub conserva inicialmente la facturación y el expediente comercial oficial. SISTEMDASHBOARD mantiene su propio modelo normalizado y sincroniza únicamente los campos autorizados por la API/documentación oficial.

## Servicios
1. Android: interfaz de operación.
2. API FastAPI: autenticación, autorización, lógica de negocio y auditoría.
3. PostgreSQL: empresas, usuarios, routers, clientes vinculados, eventos y sincronizaciones.
4. Adaptador WispHub: sincronización incremental; nunca almacenar claves en la app.
5. Adaptador MikroTik: comunicación desde el backend hacia routers por túnel WireGuard; permisos mínimos.
6. Panel web: administración de empresas, usuarios, integraciones y soporte.

## Multiempresa
Todas las entidades de negocio deben incluir `tenant_id`. Aplicar aislamiento en la API y PostgreSQL Row-Level Security antes de producción. Un usuario solo consulta datos de su empresa.

## Integración segura
- Credenciales WispHub guardadas cifradas en el servidor.
- No exponer RouterOS API a Internet.
- WireGuard termina en el VPS/red privada.
- Operaciones de escritura con confirmación, auditoría e idempotencia.
- Comenzar con lectura solamente.

## Fases
1. APK de demostración y API base.
2. Login, empresas y usuarios.
3. Conector WispHub en modo lectura.
4. Inventario y monitoreo MikroTik por WireGuard.
5. Clientes, pagos y reportes sincronizados.
6. Acciones controladas, auditoría y publicación.
