package com.puntorojo.sistemdashboard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Red = Color(0xFFE53935)
private val Muted = Color(0xFF9AA8BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DashboardApp() }
    }
}

@Composable
fun DashboardApp() {
    var selected by remember { mutableStateOf("Resumen") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Resumen", "Clientes", "Red", "Ajustes").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(when(item) {
                                    "Clientes" -> Icons.Default.People
                                    "Red" -> Icons.Default.Router
                                    "Ajustes" -> Icons.Default.Settings
                                    else -> Icons.Default.Dashboard
                                }, contentDescription = item)
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when(selected) {
                "Resumen" -> Overview(Modifier.padding(padding))
                "Clientes" -> PlaceholderPage("Clientes", "La lista se conectará a WispHub mediante su API.")
                "Red" -> PlaceholderPage("Estado de red", "Aquí aparecerán los routers, PPPoE, tráfico y OLT.")
                else -> PlaceholderPage("Configuración", "Conexiones, empresa, usuarios y seguridad.")
            }
        }
    }
}

@Composable
fun Overview(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("SISTEMDASHBOARD", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Centro de control WISP", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Surface(color = Color(0xFF38252A), shape = RoundedCornerShape(10.dp)) {
                Text("MODO DEMOSTRACIÓN · Datos de ejemplo", color = Color(0xFFFFB4AB),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 12.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Clientes", "225", "Ejemplo", Modifier.weight(1f))
                MetricCard("Conectados", "198", "Ejemplo", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Desconectados", "27", "Ejemplo", Modifier.weight(1f))
                MetricCard("Routers", "2", "Sin conexión", Modifier.weight(1f))
            }
        }
        item {
            Text("Accesos rápidos", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        item {
            QuickAction(Icons.Default.PersonAdd, "Administrar clientes", "Consultar clientes y servicios")
            QuickAction(Icons.Default.ReceiptLong, "Facturación", "Facturas, pagos y balances")
            QuickAction(Icons.Default.Router, "MikroTik", "Routers, PPPoE y tráfico")
            QuickAction(Icons.Default.SettingsInputAntenna, "OLT / ONU", "Puertos PON y potencia óptica")
        }
        item {
            Text("Integraciones pendientes de configurar: WispHub API y túnel WireGuard.",
                color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text(value, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun QuickAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Red, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PlaceholderPage(title: String, message: String) {
    Column(Modifier.fillMaxSize().background(Navy).padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(message, color = Muted)
        Spacer(Modifier.height(20.dp))
        Text("Módulo planificado para la siguiente etapa.", color = Red, fontSize = 12.sp)
    }
}
