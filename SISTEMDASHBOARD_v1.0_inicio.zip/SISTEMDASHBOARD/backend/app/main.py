from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime, timezone

app = FastAPI(
    title="SISTEMDASHBOARD API",
    version="1.0.0",
    description="API central para administración multi-WISP."
)

class DashboardSummary(BaseModel):
    mode: str
    clients_total: int
    clients_online: int
    clients_offline: int
    routers_total: int
    generated_at: str

@app.get("/health")
def health():
    return {"status": "ok", "service": "SISTEMDASHBOARD API"}

@app.get("/api/v1/dashboard/summary", response_model=DashboardSummary)
def dashboard_summary():
    # Datos demostrativos: sustituir por datos sincronizados y autorizados.
    return DashboardSummary(
        mode="demo",
        clients_total=225,
        clients_online=198,
        clients_offline=27,
        routers_total=2,
        generated_at=datetime.now(timezone.utc).isoformat()
    )
