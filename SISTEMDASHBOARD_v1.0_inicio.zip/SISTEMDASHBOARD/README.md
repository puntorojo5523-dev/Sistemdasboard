# SISTEMDASHBOARD

Plataforma de administración WISP. Estrategia BOTH: WispHub continúa como sistema de facturación principal mientras SISTEMDASHBOARD mantiene su propia capa de datos y control.

## Primera entrega
- APK Android nativa con Kotlin + Jetpack Compose.
- Dashboard inicial con métricas de demostración claramente identificadas.
- Backend FastAPI con endpoint de salud y resumen.
- Base preparada para PostgreSQL y futura sincronización WispHub/MikroTik.
- GitHub Actions para compilar APK debug.

> Esta versión es un prototipo funcional de interfaz/API. No conecta todavía con una cuenta WispHub ni ejecuta cambios en MikroTik. Para habilitarlo hacen falta credenciales/API oficiales, VPS y configuración WireGuard. No guardes secretos en el APK ni en Git.

## Estructura
- `android/`: aplicación Android.
- `backend/`: API FastAPI.
- `.github/workflows/android.yml`: compilación automática APK.
- `docs/`: arquitectura y plan de integración.

## Compilar APK
1. Sube el contenido de este proyecto a un repositorio GitHub.
2. Abre **Actions** y ejecuta `Android Debug APK` (o haz push a `main`).
3. Descarga el artefacto `SISTEMDASHBOARD-debug-apk`.
4. Instala el APK en Android habilitando la instalación desde esa fuente.

## Ejecutar backend local
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API: `http://127.0.0.1:8000`; documentación: `/docs`.

## Seguridad
La app inicial usa datos de muestra. Antes de producción: autenticación, TLS, aislamiento multiempresa, auditoría, cifrado de secretos y pruebas de permisos.
